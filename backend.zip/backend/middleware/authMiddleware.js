import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL || '';
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || '';

const isSupabaseConfigured =
  Boolean(supabaseUrl) &&
  !supabaseUrl.includes('YOUR_') &&
  Boolean(supabaseAnonKey) &&
  !supabaseAnonKey.includes('YOUR_');

let supabaseAuthClient = null;

if (isSupabaseConfigured) {
  try {
    supabaseAuthClient = createClient(
      supabaseUrl,
      supabaseAnonKey
    );
  } catch (e) {
    console.warn(
      '[AuthMiddleware] Supabase auth client init failed:',
      e.message
    );
  }
}

// Check whether the token belongs to a local/demo user
const isMockToken = (token) => {
  return (
    token === 'demo-token' ||
    (typeof token === 'string' && token.startsWith('mock-'))
  );
};

// Create a local/demo user from the mock token
const createMockUser = (token) => {
  const userId = token.startsWith('mock-')
    ? token
    : 'demo-facilitator-001';

  return {
    id: userId,
    email: 'alex.facilitator@vibecraft.ai',
    user_metadata: {
      full_name: 'Alex Morgan',
      role: 'Team Lead'
    }
  };
};


/**
 * Strict authentication
 *
 * Supports:
 * 1. Real Supabase users
 * 2. Local/demo users
 */
export async function requireAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;

    // No token
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        error: 'Unauthorized',
        message: 'Authentication required to access this resource.'
      });
    }

    const token = authHeader.slice(7).trim();

    // ==========================================
    // LOCAL / DEMO USER
    // ==========================================
    //
    // IMPORTANT:
    // Never send mock tokens to Supabase.
    //
    if (isMockToken(token)) {
      req.user = createMockUser(token);
      req.token = token;
      req.isDemoUser = true;

      return next();
    }

    // ==========================================
    // REAL SUPABASE USER
    // ==========================================

    if (isSupabaseConfigured && supabaseAuthClient) {
      const {
        data: { user },
        error
      } = await supabaseAuthClient.auth.getUser(token);

      if (error || !user) {
        return res.status(401).json({
          error: 'Unauthorized',
          message: 'Invalid or expired session token.'
        });
      }

      req.user = user;
      req.token = token;
      req.isDemoUser = false;

      return next();
    }

    // ==========================================
    // SUPABASE NOT CONFIGURED
    // ==========================================

    return res.status(401).json({
      error: 'Unauthorized',
      message: 'Authentication service is not configured.'
    });

  } catch (err) {
    console.error(
      '[AuthMiddleware] Error validating token:',
      err
    );

    return res.status(500).json({
      error: 'Internal server error during authentication.'
    });
  }
}


/**
 * Optional authentication
 *
 * Local/demo users and real Supabase users
 * are both supported.
 */
export async function optionalAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;

    // No authentication
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      req.user = null;
      req.token = null;
      req.isDemoUser = false;

      return next();
    }

    const token = authHeader.slice(7).trim();

    // ==========================================
    // LOCAL / DEMO USER
    // ==========================================

    if (isMockToken(token)) {
      req.user = createMockUser(token);
      req.token = token;
      req.isDemoUser = true;

      return next();
    }

    // ==========================================
    // REAL SUPABASE USER
    // ==========================================

    if (isSupabaseConfigured && supabaseAuthClient) {
      const {
        data: { user }
      } = await supabaseAuthClient.auth.getUser(token);

      req.user = user || null;
      req.token = token;
      req.isDemoUser = !!user;

      return next();
    }

// Supabase not configured
req.user = null;
req.token = null;
req.isDemoUser = false;

return next();

  } catch (err) {
    console.error(
      '[AuthMiddleware] Optional auth error:',
      err
    );

    req.user = null;
    req.token = null;
    req.isDemoUser = false;

    return next();
  }
}
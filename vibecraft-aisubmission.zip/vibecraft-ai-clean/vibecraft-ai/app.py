#!/usr/bin/env python3
"""
VibeCraft AI - Root Python Entrypoint
-------------------------------------
Launches the VibeCraft AI backend server in Python.
"""
import sys
import os

# Add backend directory to sys.path
backend_dir = os.path.join(os.path.dirname(__file__), 'backend')
sys.path.insert(0, backend_dir)

from app import run_server

if __name__ == '__main__':
    run_server()
